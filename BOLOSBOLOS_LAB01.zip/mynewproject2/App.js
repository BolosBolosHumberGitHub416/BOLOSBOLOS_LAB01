import { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, TextInput } from 'react-native';


export default function App() {

  const [inputText, setInputText] = useState('');

  return (
    <View style={styles.container}>
      <Text> Welcome to my React Native App! </Text>
      <Text> My name is Bolos Bolos! </Text>
      <Text> You can type in anything in this text box below. </Text>
      
      <TextInput
        style={{
          margin: 30,
          height: 200,
          width: 300,
          borderColor: 'black',
          borderWidth: 1,
        }}
        value = {inputText}
        onChangeText = { text => setInputText(text) }
        defaultValue="You can type in anything for me"
        multiline={true}
        textAlignVertical="top"
      />
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
